#!/bin/bash
tmux new-session -d -s hyperopt_session "python janestreet_cross_validation_V2.py"
