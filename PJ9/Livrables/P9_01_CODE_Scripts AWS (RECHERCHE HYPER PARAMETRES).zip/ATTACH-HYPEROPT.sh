#!/bin/bash
tmux attach -t hyperopt_session
